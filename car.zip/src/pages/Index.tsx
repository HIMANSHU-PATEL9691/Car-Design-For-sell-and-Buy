import { Link } from "react-router-dom";
import { ArrowRight, Car, Shield, Star, TrendingUp, Users, CheckCircle, Award, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CarCard from "@/components/CarCard";

import heroCar from "@/assets/hero-car.jpg";
import carMercedes from "@/assets/car-mercedes.jpg";
import carBmw from "@/assets/car-bmw.jpg";
import carAudi from "@/assets/car-audi.jpg";
import carToyota from "@/assets/car-toyota.jpg";
import carHyundai from "@/assets/car-hyundai.jpg";
import carHonda from "@/assets/car-honda.jpg";

import founderImg from "@/assets/owner.jpg";
import inspectorImg from "@/assets/owner.jpg";
import whyChooseImg from "@/assets/hero-car.jpg";



// Animation Variants
const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  initial: {},
  whileInView: { transition: { staggerChildren: 0.1 } }
};

const featuredCars = [
  { id: "1", image: carMercedes, name: "Mercedes-Benz C-Class 2023", price: 5500000, year: 2023, km: 12000, fuel: "Petrol", transmission: "Automatic", emi: 45000, isVerified: true },
  { id: "2", image: carBmw, name: "BMW 3 Series 320d Sport", price: 4800000, year: 2022, km: 25000, fuel: "Diesel", transmission: "Automatic", emi: 38000, isVerified: true },
  { id: "3", image: carAudi, name: "Audi A4 Premium Plus", price: 4200000, year: 2021, km: 35000, fuel: "Petrol", transmission: "Automatic", emi: 35000, isVerified: true },
  { id: "4", image: carToyota, name: "Toyota Fortuner Legender", price: 4500000, year: 2023, km: 8000, fuel: "Diesel", transmission: "Automatic", emi: 42000, isVerified: true },
  { id: "5", image: carHyundai, name: "Hyundai Creta SX(O)", price: 1800000, year: 2023, km: 5000, fuel: "Petrol", transmission: "Automatic", emi: 18000, isVerified: true },
  { id: "6", image: carHonda, name: "Honda City ZX CVT", price: 1500000, year: 2022, km: 18000, fuel: "Petrol", transmission: "CVT", emi: 15000, isVerified: true },
];

const stats = [
  { icon: Car, value: "10,000+", label: "Cars Sold" },
  { icon: Users, value: "50,000+", label: "Happy Customers" },
  { icon: Star, value: "4.9/5", label: "Rating" },
  { icon: TrendingUp, value: "₹500Cr+", label: "Value Traded" },
];

const whyChooseUs = [
  { icon: Shield, title: "Verified Cars", description: "Every car goes through 200+ inspection points" },
  { icon: CheckCircle, title: "No Hidden Charges", description: "Transparent pricing with no surprise fees" },
  { icon: Star, title: "Best Prices", description: "Get the best market value for your car" },
  { icon: TrendingUp, title: "Easy Finance", description: "Quick loan approval with low EMI options" },
];

const specializations = [
  { icon: Sparkles, title: "Luxury Sedans", count: "250+", description: "Premium comfort and performance" },
  { icon: Award, title: "Sport SUVs", count: "180+", description: "Power meets versatility" },
  { icon: TrendingUp, title: "Electric Vehicles", count: "90+", description: "The future of sustainable driving" },
  { icon: Shield, title: "Vintage Classics", count: "45+", description: "Timeless pieces for collectors" },
];

const testimonials = [
  { name: "Rahul Sharma", role: "BMW 3 Series Owner", content: "The verification process at AutoHub gave me complete peace of mind. Highly recommended!", rating: 5 },
  { name: "Priya Patel", role: "Sold Mercedes C-Class", content: "Got a much better price than I expected. The valuation was quick and professional.", rating: 5 },
];
const team = [
  {
    name: "HIMANSHU PATEL",
    role: "Founder & CEO",
    description: "15+ years in the luxury automobile industry.",
    image: founderImg,
  },
  {
    name: "HIMANSHU PATEL",
    role: "Head of Inspections",
    description: "Expert in 200-point car verification.",
    image: inspectorImg,
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background selection:bg-primary/30">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-[95vh] flex items-center overflow-hidden">
        <motion.div 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0"
        >
          <img src={heroCar} alt="Hero" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/20 to-transparent" />
          {/* <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" /> */}
        </motion.div>

        <div className="container mx-auto px-4 relative z-10 pt-20">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl space-y-8"
          >
            <div className="inline-flex items-center gap-2 bg-primary/10 backdrop-blur-md px-4 py-2 rounded-full text-sm text-primary font-medium border border-primary/20">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              India's Premier Luxury Car Hub
            </div>

            <h1 className="text-6xl md:text-8xl font-display font-bold text-foreground leading-[1.1] tracking-tight">
              Elevate Your <br />
              <span className="text-gradient-primary">Driving Legacy</span>
            </h1>

            <p className="text-xl text-muted-foreground max-w-lg leading-relaxed">
              Experience a seamless journey in buying and selling verified premium cars with complete transparency.
            </p>

            <div className="flex flex-wrap gap-5">
              <Button variant="hero" size="xl" className="group shadow-glow" asChild>
                <Link to="/buy">
                  <Car className="w-5 h-5 transition-transform group-hover:-rotate-12" />
                  Explore Collection
                </Link>
              </Button>
              <Button variant="outline" size="xl" className="backdrop-blur-sm" asChild>
                <Link to="/sell">
                  Sell Your Car
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-10 border-t border-border/50">
              {stats.map((stat, idx) => (
                <motion.div 
                  key={stat.label}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 + idx * 0.1 }}
                  className="space-y-1"
                >
                  <div className="flex items-center gap-2 text-primary">
                    <stat.icon className="w-5 h-5" />
                    <span className="text-2xl font-bold text-foreground tracking-tighter">{stat.value}</span>
                  </div>
                  <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Cars Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div {...fadeInUp} className="flex flex-col md:flex-row justify-between items-end gap-6 mb-16">
            <div className="space-y-3">
              <h2 className="text-4xl md:text-5xl font-display font-bold">The Curated Gallery</h2>
              <p className="text-muted-foreground text-lg">Handpicked masterpieces, verified for perfection.</p>
            </div>
            <Button variant="ghost" className="group text-primary hover:bg-primary/5" asChild>
              <Link to="/buy">
                View Full Inventory
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="whileInView"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {featuredCars.map((car) => (
              <motion.div key={car.id} variants={fadeInUp}>
                <CarCard {...car} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Specialization Section */}
      <section className="py-24 bg-secondary/10 relative">
        <div className="container mx-auto px-4">
          <motion.div {...fadeInUp} className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6">Our Expertise</h2>
            <div className="h-1 w-20 bg-primary mx-auto rounded-full mb-6" />
            <p className="text-muted-foreground text-lg">We specialize in niche categories to ensure you find exactly what your heart desires.</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {specializations.map((spec, idx) => (
              <motion.div 
                key={spec.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                whileHover={{ y: -10 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-card p-10 rounded-2xl border border-border/50 hover:border-primary/40 transition-all text-center group shadow-sm hover:shadow-glow"
              >
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary group-hover:text-white transition-colors">
                  <spec.icon className="w-8 h-8" />
                </div>
                <h3 className="text-primary text-4xl font-bold mb-2 tracking-tighter">{spec.count}</h3>
                <h4 className="text-xl font-display font-semibold mb-3">{spec.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{spec.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
{/* Why Choose Us Section */}
<section className="py-24 overflow-hidden">
  <div className="container mx-auto px-4">
    <div className="grid lg:grid-cols-2 gap-16 items-center">
      
      {/* Left Content */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="space-y-8"
      >
        <h2 className="text-4xl md:text-5xl font-display font-bold leading-tight">
          Why AutoHub is the <span className="text-primary">Trusted Choice</span>
        </h2>

        <p className="text-lg text-muted-foreground">
          We've redefined the car buying experience with a focus on trust, speed,
          and luxury service.
        </p>

        <div className="grid sm:grid-cols-2 gap-6">
          {whyChooseUs.map((item) => (
            <div
              key={item.title}
              className="flex gap-4 p-4 rounded-xl border border-border/50
                         hover:bg-secondary/50 transition-colors"
            >
              <div className="shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <item.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h4 className="font-bold">{item.title}</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Right Image */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="relative aspect-square rounded-3xl overflow-hidden group"
      >
        {/* Image */}
        <img
          src={whyChooseImg}
          alt="Why Choose AutoHub"
          className="w-full h-full object-cover
                     scale-100 group-hover:scale-105
                     transition-transform duration-700"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-background/10 via-transparent to-primary/20" />

        {/* Texture Overlay (premium feel) */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />

        {/* Soft Border */}
        <div className="absolute inset-0 rounded-3xl ring-1 ring-primary/20" />
      </motion.div>

    </div>
  </div>
</section>


      {/* Testimonials Section */}
      <section className="py-24 bg-card relative">
        <div className="container mx-auto px-4">
          <motion.h2 {...fadeInUp} className="text-4xl md:text-5xl font-display font-bold text-center mb-20">Voices of Satisfaction</motion.h2>
          <div className="grid md:grid-cols-2 gap-10 max-w-6xl mx-auto">
            {testimonials.map((t, idx) => (
              <motion.div 
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.2 }}
                className="bg-background p-10 rounded-3xl border border-border relative group"
              >
                <Star className="w-12 h-12 text-primary/10 absolute -top-4 -right-4 fill-primary/10 group-hover:rotate-12 transition-transform" />
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-primary text-primary" />)}
                </div>
                <p className="text-xl italic mb-8 leading-relaxed text-foreground/90 font-medium">"{t.content}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center font-bold text-primary">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-lg leading-none">{t.name}</p>
                    <p className="text-sm text-primary mt-1 font-medium">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      

      {/* Team/Owner Section */}
<section className="py-24 bg-background relative overflow-hidden">
  {/* Decorative Background */}
  <div className="absolute inset-0 opacity-5 pointer-events-none">
    <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-primary rounded-full blur-[120px]" />
    <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent rounded-full blur-[120px]" />
  </div>

  <div className="container mx-auto px-4 relative z-10">
    {/* Header */}
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      viewport={{ once: true }}
      className="max-w-3xl mx-auto text-center mb-20"
    >
      <div className="inline-block px-4 py-1.5 mb-4 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-widest">
        Our Leadership
      </div>
      <h2 className="text-4xl md:text-5xl font-display font-bold">
        The Visionaries
      </h2>
      <p className="text-muted-foreground mt-4 text-lg">
        Leading the charge in Indian luxury automobile innovation with transparency and trust.
      </p>
    </motion.div>

    {/* Cards */}
    <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
      {team.map((member, idx) => (
        <motion.div
          key={member.name}
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: idx * 0.15, duration: 0.6, ease: "easeOut" }}
          viewport={{ once: true }}
          className="group relative p-8 rounded-[2.5rem] bg-card border border-border/50
                     hover:border-primary/30 transition-all duration-500 hover:shadow-glow"
        >
          <div className="flex flex-col items-center text-center space-y-6">
            
            {/* Image */}
            <div className="relative">
              {/* Soft glow */}
              <div className="absolute inset-0 rounded-full bg-primary/30 blur-xl opacity-0
                              group-hover:opacity-60 transition-opacity duration-500" />

              <div className="w-44 h-44 rounded-full bg-gradient-to-tr from-primary via-accent to-primary
                              p-1.5 transition-transform duration-700 ease-out
                              group-hover:rotate-6">
                <div className="w-full h-full rounded-full overflow-hidden bg-background border-4 border-background">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover
                               transition-transform duration-700 ease-out
                               group-hover:scale-105"
                  />
                </div>
              </div>

              {/* Verified badge */}
              <div className="absolute -bottom-1 -right-1 bg-primary text-white p-2 rounded-full
                              shadow-lg border-4 border-background
                              transition-transform duration-300 group-hover:scale-110">
                <Shield className="w-5 h-5" />
              </div>
            </div>

            {/* Text */}
            <div className="space-y-3">
              <h3 className="text-2xl font-display font-bold transition-colors duration-300 group-hover:text-primary">
                {member.name}
              </h3>

              <div className="flex items-center justify-center gap-2">
                <span className="h-px w-4 bg-primary/40" />
                <p className="text-primary font-bold uppercase tracking-[0.25em] text-[10px]">
                  {member.role}
                </p>
                <span className="h-px w-4 bg-primary/40" />
              </div>

              <p className="text-muted-foreground max-w-xs mx-auto text-sm leading-relaxed
                            opacity-80 group-hover:opacity-100 transition-opacity duration-300">
                {member.description}
              </p>
            </div>

          </div>
        </motion.div>
      ))}
    </div>
  </div>
</section>

{/* CTA Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            className="relative rounded-[3rem] overflow-hidden bg-card border border-border p-16 md:p-24 text-center group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20 group-hover:opacity-70 transition-opacity" />
            <div className="relative z-10 max-w-3xl mx-auto space-y-8">
              <h2 className="text-5xl md:text-7xl font-display font-bold tracking-tight leading-none">
                Ready to Sell <br /> <span className="text-gradient-primary">In 24 Hours?</span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-lg mx-auto leading-relaxed">
                Get an instant valuation and guaranteed best price. No paperwork stress, just pure value.
              </p>
              <div className="pt-6">
                <Button variant="hero" size="xl" className="h-16 px-10 text-lg shadow-glow-primary group" asChild>
                  <Link to="/sell">
                    Get Free Valuation
                    <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-2 transition-transform" />
                  </Link>
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;